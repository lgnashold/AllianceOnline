colors = {"team1" : "#DE6B48", "team2":"#F4B9B2", "team3": "#DAEDBD", "team4": "#7DBBC3"}
